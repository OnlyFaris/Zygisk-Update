enforce_install_from_magisk_app() {
  if ! $BOOTMODE; then
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Some recovery has broken implementations, install with such recovery will finally cause Riru or Zygisk modules not working"
    ui_print "! Please install from Magisk app"
    abort "*********************************************************"
  fi
}


check_available_game() {
  isGameAvailable=false
 # for game in "com.kakaogames.gdts" "com.xlua.app" "com.apsoksmdmd" "com.soxkks" "com.aosdnsn"; do
  for game in "com.kakaogames.gdts" ; do
  
    if [ -d "/data/data/$game" ]; then
      ui_print "- Valid game detected: $game"
      app_data_dir="/data/data/$game/module_files"
      mkdir "$app_data_dir"
      echo "" > "$app_data_dir/imgui.ini"
      isGameAvailable=true
    fi
  done

  if [ $isGameAvailable = false ]; then
    ui_print "*********************************************************"
    ui_print "! Can't Find This Game In Your Device :( "
    ui_print "! Please Install Before Flashing This Module"
    abort "*********************************************************"
  fi
}

check_android_version() {
  if ! [ "$API" -ge 24 ]; then
    ui_print "*********************************************************"
    ui_print "! Unsupported Android version $API (below Oreo MR1)"
    abort "*********************************************************"
  fi
}
