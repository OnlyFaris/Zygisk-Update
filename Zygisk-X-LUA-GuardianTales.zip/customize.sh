SKIPUNZIP=1
MODULE_LIB_NAME="zygisk-XLuaApp"

# Extract verify.sh
ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort "*********************************************************"
fi
. "$TMPDIR/verify.sh"

extract "$ZIPFILE" 'util_functions.sh' "$TMPDIR" true
. "$TMPDIR/util_functions.sh"
enforce_install_from_magisk_app
check_android_version

# Check architecture
if [ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

check_available_game

# Extract libs
ui_print "- Extracting module files"
extract "$ZIPFILE" 'module.prop' "$MODPATH"
extract "$ZIPFILE" 'uninstall.sh' "$MODPATH"


mkdir "$MODPATH/zygisk"
if [ "$ARCH" = "arm" ] || [ "$ARCH" = "arm64" ]; then
  extract "$ZIPFILE" "lib/armeabi-v7a/lib$MODULE_LIB_NAME.so" "$MODPATH/zygisk" true
  mv "$MODPATH/zygisk/lib$MODULE_LIB_NAME.so" "$MODPATH/zygisk/armeabi-v7a.so"


if [ "$IS64BIT" = true ]; then
 extract "$ZIPFILE" "lib/arm64-v8a/lib$MODULE_LIB_NAME.so" "$MODPATH/zygisk" true
 mv "$MODPATH/zygisk/lib$MODULE_LIB_NAME.so" "$MODPATH/zygisk/arm64-v8a.so"
 fi

fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
